# Trabalho INF 1301 - 18.1
Programa :computer: que implementa um jogo de truco :black_joker: em linguagem C para a matéria INF1301 da PUC-Rio :mortar_board:.

### To Do:
- [ ] Wait for T3 :raised_hands:. 

**Grupo AWBRVM**:
        *Único que presta no Git* :sunglasses:
